// Navigation Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
    const menuBtn = document.getElementById('menuBtn');
    const navMenu = document.getElementById('navMenu');
    
    menuBtn.addEventListener('click', function() {
        navMenu.classList.toggle('active');
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!menuBtn.contains(event.target) && !navMenu.contains(event.target)) {
            navMenu.classList.remove('active');
        }
    });
    
    // Close menu when clicking on a nav link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navMenu.classList.remove('active');
        });
    });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add scroll effect to header
window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'rgba(0, 20, 40, 0.98)';
    } else {
        header.style.background = 'rgba(0, 20, 40, 0.95)';
    }
});

// Add intersection observer for module cards animation
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe all module cards
document.querySelectorAll('.module-card').forEach(card => {
    observer.observe(card);
});

// Add loading animation
window.addEventListener('load', function() {
    document.body.classList.add('loaded');
});

// Add parallax effect to background
window.addEventListener('scroll', function() {
    const scrolled = window.pageYOffset;
    const parallax = document.querySelector('body');
    const speed = scrolled * 0.5;
    parallax.style.backgroundPosition = `center ${speed}px`;
});

// Add hover sound effect (optional)
function playHoverSound() {
    // This would play a subtle sound effect on hover
    // Implementation would require audio files
}

// Module card hover effects
document.querySelectorAll('.module-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-10px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0) scale(1)';
    });
});

// Add typing effect to hero title (optional enhancement)
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// Initialize typing effect on load
window.addEventListener('load', function() {
    const heroTitle = document.querySelector('.hero-title');
    if (heroTitle) {
        const originalText = heroTitle.textContent;
        typeWriter(heroTitle, originalText, 150);
    }
});

// Add search functionality for modules
function searchModules(query) {
    const modules = document.querySelectorAll('.module-card');
    const searchTerm = query.toLowerCase();
    
    modules.forEach(module => {
        const title = module.querySelector('.module-title').textContent.toLowerCase();
        const description = module.querySelector('.module-description').textContent.toLowerCase();
        
        if (title.includes(searchTerm) || description.includes(searchTerm)) {
            module.style.display = 'block';
            module.style.opacity = '1';
        } else {
            module.style.display = 'none';
        }
    });
}

// Add keyboard navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('navMenu').classList.remove('active');
    }
});

// Performance optimization: Lazy load images
const images = document.querySelectorAll('img[data-src]');
const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.classList.remove('lazy');
            imageObserver.unobserve(img);
        }
    });
});

images.forEach(img => imageObserver.observe(img));



function calculateDSCR() {
    const noi = parseFloat(document.getElementById("dscr-noi").value);
    const debt = parseFloat(document.getElementById("dscr-debt").value);

    if (noi && debt && debt > 0) {
        const dscr = noi / debt;
        document.getElementById("dscr-result").textContent = `DSCR: ${dscr.toFixed(2)}`;
    } else {
        document.getElementById("dscr-result").textContent = "Please enter valid values";
    }
}



function calculateCashOnCash() {
    const annualCashFlow = parseFloat(document.getElementById("coc-annual-cash-flow").value);
    const totalCashInvested = parseFloat(document.getElementById("coc-total-cash-invested").value);

    if (annualCashFlow && totalCashInvested && totalCashInvested > 0) {
        const cashOnCash = (annualCashFlow / totalCashInvested) * 100;
        document.getElementById("coc-result").textContent = `Cash-on-Cash: ${cashOnCash.toFixed(2)}%`;
    } else {
        document.getElementById("coc-result").textContent = "Please enter valid values";
    }
}

function calculateIRR() {
    const initialInvestment = parseFloat(document.getElementById("irr-initial-investment").value);
    const cashFlowsInput = document.getElementById("irr-cash-flows").value;
    const cashFlows = cashFlowsInput.split(",").map(Number);

    if (initialInvestment && cashFlows.length > 0 && !cashFlows.some(isNaN)) {
        // Simple approximation for IRR - for a more robust solution, a dedicated library would be needed
        // This is a basic implementation for demonstration purposes
        let irr = 0.1; // Initial guess
        const maxIterations = 1000;
        const tolerance = 0.0001;

        for (let i = 0; i < maxIterations; i++) {
            let npv = -initialInvestment;
            for (let j = 0; j < cashFlows.length; j++) {
                npv += cashFlows[j] / Math.pow(1 + irr, j + 1);
            }

            let derivative = 0;
            for (let j = 0; j < cashFlows.length; j++) {
                derivative -= (cashFlows[j] * (j + 1)) / Math.pow(1 + irr, j + 2);
            }

            const newIrr = irr - npv / derivative;
            if (Math.abs(newIrr - irr) < tolerance) {
                irr = newIrr;
                break;
            }
            irr = newIrr;
        }

        document.getElementById("irr-result").textContent = `IRR: ${(irr * 100).toFixed(2)}%`;
    } else {
        document.getElementById("irr-result").textContent = "Please enter valid values";
    }
}


